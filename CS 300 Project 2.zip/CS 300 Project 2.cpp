// CS 300 Project 2.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Author : Cristian Chavez
// Date : 10/16/22


#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
using namespace std;


int main()
{
	int userChoice = 0;
	ifstream inFS; 
	string line;
	vector<string> courses;
	string option;

	cout << "Welcome to the ABCU advising program!\n" << "Please select one of the following options!\n";

	while (userChoice != 9) { 
		cout << "Menu:" << endl;
		cout << "1. Load Data Structure" << endl;
		cout << "2. Print Course List" << endl;
		cout << "3. Print Course" << endl;
		cin >> userChoice;

		switch (userChoice) {
		case 1:

			inFS.open("courses.txt"); //Opens text file

			if (!inFS.is_open()) { //Error if text file doesn't execute
				cout << "Could not open courses.txt";
			}
		
			while (!inFS.eof()) { //Go through entire file
				getline(inFS, line); //Get entire line from mile
				courses.push_back(line); //Add line to vector
			}

			inFS.close();
			cout << "Data successfully loaded\n\n";
			break;

		case 2:
			cout << "\nHere is a sample schedule:\n";
			sort(courses.begin(), courses.end()); //Sort vector 
			for (int i = 0; i < courses.size(); ++i) { 
				string myStr = courses[i]; //Set myStr to current line
				vector<string> info; //Create new vector
				stringstream idCourse(myStr); //Create stringstream IdCourse using current line
				while (idCourse.good()) { //Check that stream has no errors
					string subStr; //subStr to hold each word or number
					getline(idCourse, subStr, ','); // getline that adds subStr with comma as delimiter
					info.push_back(subStr); // add each subStr to vector info
				}
					cout << info[0] << " " << info[1] << endl; //Print first and second subStr from vector
			}
			cout << endl;
			break;

		case 3: 
			cout << "\nWhat course do you want to know about?\n";
			cin >> option;
			cout << endl;
			sort(courses.begin(), courses.end());
			for (int i = 0; i < courses.size(); ++i) {
				string myStr = courses[i];
				vector<string> info;
				stringstream idCourse(myStr); //Same code as used previously
				while (idCourse.good()) {
					string subStr;
					getline(idCourse, subStr, ',');
					info.push_back(subStr);
				}

				if (option == info[0]) {  //If class number chosen by user is equal to the class number in the vector
					if (info.size() == 2) { // If there are only 2 subStr
						cout << info[0] << " " << info[1] << "\nPrerequisites: None \n";
					}
					else if (info.size() == 3) { // If there 3 subStr
						cout << info[0] << " " << info[1] << "\nPrerequisites: " << info[2] << endl;
					}
					else if (info.size() == 4) { //If there are 4 subStr
						cout << info[0] << " " << info[1] << "\nPrerequisites: " << info[2] << " , " << info[3] << endl;
					}
				}
			}
			cout << endl;

			break;

		default:
			cout << "Invalid Entry, Please Try Again.\n\n";
			break;
		}
	}
	cout << "Thank you for using the ABSU advising program!\n\n";

}


